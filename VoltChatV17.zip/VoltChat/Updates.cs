using System.Diagnostics;
using System.Net.Http;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
namespace VoltChat;
public partial class MainWindow
{
    const string UpdateFeed = "https://raw.githubusercontent.com/postnlpieter97-coder/VoltChat-Updates/main/update.json";
    static readonly Version InstalledVersion = new(17,0,0);
    static readonly HttpClient UpdateHttp = new() { Timeout = TimeSpan.FromSeconds(15) };
    bool updateNoticeShown;
    sealed record AvailableUpdate(Version Version, Uri Page);
    static async Task<AvailableUpdate?> CheckUpdateAsync()
    {
        using var response = await UpdateHttp.GetAsync(UpdateFeed, HttpCompletionOption.ResponseHeadersRead);
        response.EnsureSuccessStatusCode();
        if(response.Content.Headers.ContentLength > 65536) throw new InvalidOperationException("Update feed is too large.");
        using var stream = await response.Content.ReadAsStreamAsync();
        using var buffer = new System.IO.MemoryStream();
        byte[] chunk = new byte[4096]; int n;
        while((n=await stream.ReadAsync(chunk.AsMemory()))>0){ if(buffer.Length+n>65536) throw new InvalidOperationException("Update feed is too large."); buffer.Write(chunk,0,n); }
        using var doc = JsonDocument.Parse(buffer.ToArray());
        var root=doc.RootElement;
        if(root.GetProperty("schema").GetInt32()!=1 || root.GetProperty("product").GetString()!="Volt Chat") throw new InvalidOperationException("Invalid update feed.");
        var release=root.GetProperty("release");
        if(release.ValueKind==JsonValueKind.Null)return null;
        if(!Version.TryParse(release.GetProperty("version").GetString(),out var version))throw new InvalidOperationException("Invalid release version.");
        if(!Uri.TryCreate(release.GetProperty("release_url").GetString(),UriKind.Absolute,out var page) || page.Scheme!=Uri.UriSchemeHttps || page.Host!="github.com" || !page.IsDefaultPort || page.UserInfo.Length!=0 || !page.AbsolutePath.StartsWith("/postnlpieter97-coder/VoltChat-Updates/releases/tag/",StringComparison.Ordinal))throw new InvalidOperationException("Untrusted release page.");
        return version>InstalledVersion?new(version,page):null;
    }
    static void OpenRelease(AvailableUpdate update)=>Process.Start(new ProcessStartInfo(update.Page.AbsoluteUri){UseShellExecute=true});
    async Task CheckUpdateOnStartup()
    {
        if(!prefs.CheckUpdates)return;
        try { var update=await CheckUpdateAsync(); if(update==null||updateNoticeShown||!IsLoaded)return; updateNoticeShown=true;
            if(MessageBox.Show(this,$"Volt Chat {update.Version} is available. Open the official release page?","Volt Chat update",MessageBoxButton.YesNo,MessageBoxImage.Information)==MessageBoxResult.Yes)OpenRelease(update);
        } catch { /* Offline startup must not block chat. */ }
    }
    void DrawUpdates(StackPanel page,Window owner)
    {
        page.Children.Add(Note($"Installed version: {InstalledVersion}"));
        var auto=new CheckBox{Content="Check for updates on startup",IsChecked=prefs.CheckUpdates,Foreground=System.Windows.Media.Brushes.White,Margin=new Thickness(0,8,0,16)};
        auto.Click+=(_,_)=>{prefs.CheckUpdates=auto.IsChecked==true;try{prefs.Save();}catch(Exception ex){MessageBox.Show(owner,ex.Message,"Volt Chat");}};page.Children.Add(auto);
        var status=Note("Check GitHub for a published release.");page.Children.Add(status);
        AvailableUpdate? found=null;
        var open=Action("Open official download",()=>{if(found!=null)try{OpenRelease(found);}catch(Exception ex){status.Text=ex.Message;}},true);open.IsEnabled=false;
        var check=Action("Check for updates",()=>{});check.Click+=async(_,_)=>{check.IsEnabled=false;open.IsEnabled=false;found=null;status.Text="Checking for updates…";try{found=await CheckUpdateAsync();status.Text=found==null?"No newer release is published.":$"Version {found.Version} is available.";open.IsEnabled=found!=null;}catch(Exception ex){status.Text="Update check failed: "+ex.Message;}finally{check.IsEnabled=true;}};
        page.Children.Add(check);page.Children.Add(open);page.Children.Add(Note("Install only trusted releases. Close Volt Chat before replacing the executable. Your local preferences and saved login are stored separately."));
    }
}
