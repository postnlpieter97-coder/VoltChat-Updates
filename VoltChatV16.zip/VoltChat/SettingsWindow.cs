using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace VoltChat;
public sealed class ClientPreferences
{
    public int StatusIndex {get;set;}=0;
    public double GlassOpacity {get;set;}=1;
    public double FontSize {get;set;}=14;
    public double Scale {get;set;}=1;
    public bool Avatars {get;set;}=true;
    public bool Timestamps {get;set;}=true;
    public bool Compact {get;set;}=false;
    public bool Animations {get;set;}=true;
    public bool SpellCheck {get;set;}=false;
    public bool RememberWindow {get;set;}=true;
    public double Width {get;set;}=1280;
    public double Height {get;set;}=800;
    public string Accent {get;set;}="#FFD500";
    static string FileName=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"VoltChat","preferences.json");
    public static ClientPreferences Load(){try{return JsonSerializer.Deserialize<ClientPreferences>(File.ReadAllText(FileName))??new();}catch{return new();}}
    public void Save(){Directory.CreateDirectory(Path.GetDirectoryName(FileName)!);File.WriteAllText(FileName+".tmp",JsonSerializer.Serialize(this));File.Move(FileName+".tmp",FileName,true);}
}
public partial class MainWindow
{
    ClientPreferences prefs=new();
    void InitPreferences(){prefs=ClientPreferences.Load();messageFont=Math.Clamp(prefs.FontSize,11,22);if(prefs.RememberWindow&&double.IsFinite(prefs.Width)&&double.IsFinite(prefs.Height)){Width=Math.Clamp(prefs.Width,MinWidth,Math.Max(MinWidth,SystemParameters.WorkArea.Width));Height=Math.Clamp(prefs.Height,MinHeight,Math.Max(MinHeight,SystemParameters.WorkArea.Height));}ApplyPreferences();Closing+=(_,_)=>{try{if(WindowState==WindowState.Normal){prefs.Width=Width;prefs.Height=Height;}prefs.Save();}catch{}};}
    void ApplyPreferences(){Opacity=1;prefs.GlassOpacity=1;messageFont=Math.Clamp(prefs.FontSize,11,22);ChatPanel.LayoutTransform=new ScaleTransform(Math.Clamp(prefs.Scale,.85,1.15),Math.Clamp(prefs.Scale,.85,1.15));SpellCheck.SetIsEnabled(Message,prefs.SpellCheck);foreach(var card in Messages.Children.OfType<Border>()){card.Padding=new Thickness(10,prefs.Compact?3:8,10,prefs.Compact?3:8);if(card.Child is Grid g){if(g.Children.OfType<Border>().FirstOrDefault() is Border a)a.Visibility=prefs.Avatars?Visibility.Visible:Visibility.Hidden;if(g.Children.OfType<StackPanel>().FirstOrDefault() is StackPanel st){if(st.Children.Count>1&&st.Children[1] is TextBlock body)body.FontSize=messageFont;if(st.Children[0] is StackPanel h&&h.Children.Count>1)h.Children[1].Visibility=prefs.Timestamps?Visibility.Visible:Visibility.Collapsed;}}}}
    static SolidColorBrush Ink(string hex)=>new((Color)ColorConverter.ConvertFromString(hex));
    TextBlock Heading(string text,int size=24)=>new(){Text=text,FontSize=size,FontWeight=FontWeights.SemiBold,Foreground=Brushes.White,Margin=new Thickness(0,0,0,14)};
    TextBlock Note(string text)=>new(){Text=text,Foreground=Ink("#9A9EAB"),TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,4,0,12)};
    Button Action(string name,System.Action action,bool primary=false){var b=new Button{Content=name,Style=(Style)FindResource(primary?"PrimaryButtonStyle":"SecondaryButtonStyle"),HorizontalAlignment=HorizontalAlignment.Left,MinWidth=140,Margin=new Thickness(0,4,0,8)};b.Click+=(_,_)=>action();return b;}
    void Settings_Click(object s,RoutedEventArgs e){OptionsPanel.Visibility=Visibility.Collapsed;var w=new Window{Owner=this,Title="Volt Chat • Settings",Width=940,Height=680,MinWidth=760,MinHeight=480,Background=Ink("#181A20"),Foreground=Brushes.White,WindowStartupLocation=WindowStartupLocation.CenterOwner,FontFamily=new FontFamily("Segoe UI"),FontSize=14};var root=new Grid();root.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(245)});root.ColumnDefinitions.Add(new ColumnDefinition());var rail=new DockPanel{Background=Ink("#131419")};root.Children.Add(rail);var brand=new TextBlock{Text="VOLT CHAT  /  SETTINGS",Foreground=Ink("#FFD500"),FontWeight=FontWeights.Bold,Margin=new Thickness(22,26,10,20)};DockPanel.SetDock(brand,Dock.Top);rail.Children.Add(brand);var done=Action("Done  /  Close",()=>w.Close(),true);done.Margin=new Thickness(14,8,14,18);done.HorizontalAlignment=HorizontalAlignment.Stretch;DockPanel.SetDock(done,Dock.Bottom);rail.Children.Add(done);var nav=new StackPanel{Margin=new Thickness(14,0,14,12)};rail.Children.Add(new ScrollViewer{Content=nav,VerticalScrollBarVisibility=ScrollBarVisibility.Auto});var page=new StackPanel{Margin=new Thickness(32,24,32,24)};var content=new ScrollViewer{Content=page,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};Grid.SetColumn(content,1);root.Children.Add(content);w.Content=root;
      void save(){try{prefs.Save();ApplyPreferences();}catch(Exception ex){MessageBox.Show(w,ex.Message,"Settings");}}
      void section(string name){nav.Children.Add(new TextBlock{Text=name,Foreground=Ink("#9A9EAB"),FontSize=11,FontWeight=FontWeights.SemiBold,Margin=new Thickness(9,18,0,6)});}
      Button? active=null;
      void tab(string title,System.Action draw){var b=Action(title,()=>{});b.Click+=(_,_)=>{if(active!=null){active.Background=Brushes.Transparent;active.Foreground=Ink("#B7BAC4");}active=b;b.Background=Ink("#24210E");b.Foreground=Ink("#FFD500");page.Children.Clear();page.Children.Add(Heading(title));draw();content.ScrollToTop();FadeIn(page);};b.Style=(Style)FindResource("Flat");b.HorizontalAlignment=HorizontalAlignment.Stretch;b.HorizontalContentAlignment=HorizontalAlignment.Left;nav.Children.Add(b);}
      void text(string value)=>page.Children.Add(Note(value));
      void toggle(string label,bool value,System.Action<bool> set){var c=new CheckBox{Content=label,Foreground=Brushes.White,IsChecked=value,Margin=new Thickness(0,10,0,12)};c.Checked+=(_,_)=>{set(true);save();};c.Unchecked+=(_,_)=>{set(false);save();};page.Children.Add(c);}
      void slider(string label,double value,double min,double max,double step,System.Action<double> set){var valueLabel=Note(label+"  •  "+value.ToString("0.##"));page.Children.Add(valueLabel);var sl=new Slider{Style=(Style)FindResource("CleanSlider"),Minimum=min,Maximum=max,Value=value,TickFrequency=step,IsSnapToTickEnabled=true,Width=320,HorizontalAlignment=HorizontalAlignment.Left,Margin=new Thickness(0,0,0,18)};sl.ValueChanged+=(_,_)=>{valueLabel.Text=label+"  •  "+sl.Value.ToString("0.##");set(sl.Value);save();};page.Children.Add(sl);}
      void account(){text("Signed in as");page.Children.Add(Heading(Identity.Text,18));text("Passwords are never stored. Sign out and use Forgot password to change your password through email.");page.Children.Add(Action("Sign out",()=>{w.Close();Logout_Click(this,new RoutedEventArgs());}));}
      section("USER SETTINGS");tab("My Account",account);tab("Privacy & Safety",()=>{text("Manage blocked contacts and report inappropriate messages from their context menu. Messages are not end-to-end encrypted.");page.Children.Add(Action("Blocked users",()=>{w.Close();BlockedContacts_Click(this,new RoutedEventArgs());}));});tab("Devices",()=>{text("Remembered sessions are encrypted using Windows DPAPI. Sign out to remove this device’s stored session.");page.Children.Add(Action("Forget saved login",()=>{try{SessionStore.Clear();RememberLogin.IsChecked=false;text("Saved login removed.");}catch(Exception ex){text(ex.Message);}}));});
      section("APP SETTINGS");tab("Appearance",()=>{text("Personalize your workspace. Changes save automatically.");slider("Chat font size",prefs.FontSize,11,22,1,v=>prefs.FontSize=v);slider("Interface scale",prefs.Scale,.85,1.15,.05,v=>prefs.Scale=v);toggle("Compact messages",prefs.Compact,v=>prefs.Compact=v);toggle("Show avatars",prefs.Avatars,v=>prefs.Avatars=v);toggle("Show timestamps",prefs.Timestamps,v=>prefs.Timestamps=v);toggle("Enable screen transitions",prefs.Animations,v=>prefs.Animations=v);text("Theme: Volt Yellow • charcoal and electric yellow");});tab("Accessibility",()=>{toggle("Reduce motion (screen transitions)",!prefs.Animations,v=>prefs.Animations=!v);slider("Message text size",prefs.FontSize,11,22,1,v=>prefs.FontSize=v);});tab("Text & Images",()=>toggle("Spell check in message composer",prefs.SpellCheck,v=>prefs.SpellCheck=v));tab("Keybinds",()=>{text("Enter — Send message\nF11 — Maximize or restore window\nTab / Shift+Tab — Navigate controls");});tab("Windows Settings",()=>toggle("Remember window size",prefs.RememberWindow,v=>prefs.RememberWindow=v));tab("Advanced",()=>{page.Children.Add(Action("Reset local preferences",()=>{if(MessageBox.Show(w,"Reset your local preferences?","Volt Chat",MessageBoxButton.YesNo)==MessageBoxResult.Yes){prefs=new();save();w.Close();}}));});section("APPLICATION INFORMATION");tab("About Volt Chat",()=>{page.Children.Add(Heading("Volt Chat V16",20));text("Connect Beyond Limits.\nPrivate conversations and invite-only spaces.");});page.Children.Add(Heading("My Account"));account();w.ShowDialog();}
}
