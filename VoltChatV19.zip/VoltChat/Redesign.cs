using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace VoltChat;
public partial class MainWindow {
 bool profileWanted=true;
 const double ProfileBreakpoint=1180;
 const double ProfileWidth=280;
 bool ProfileFits=>ActualWidth>=ProfileBreakpoint*Math.Clamp(prefs.Scale,.85,1.15);
 void InitRedesign(){
  SizeChanged+=(_,_)=>AdjustProfile();
  // A borderless window with WindowChrome overflows the screen by its resize border when maximized; pad it back in.
  StateChanged+=(_,_)=>{bool max=WindowState==WindowState.Maximized;WindowFrame.Margin=max?SystemParameters.WindowResizeBorderThickness:new Thickness(0);MaxButton.Content=max?"\uE923":"\uE922";MaxButton.ToolTip=max?"Restore":"Maximize";};
  LocalStatus.SelectedIndex=Math.Clamp(prefs.StatusIndex,0,2);
  AdjustProfile();
 }
 void AdjustProfile(){if(ProfilePane==null)return;bool show=profileWanted&&ProfileFits;ProfilePane.Visibility=show?Visibility.Visible:Visibility.Collapsed;ProfileColumn.Width=new GridLength(show?ProfileWidth:0);}
 void ToggleProfile_Click(object s,RoutedEventArgs e){
  profileWanted=!profileWanted;
  if(!ProfileFits){
   var w=Dialog("Your profile");
   var panel=new StackPanel{Margin=new Thickness(24)};
   panel.Children.Add(Heading(DisplayName.Text,20));
   panel.Children.Add(Note(Identity.Text));
   panel.Children.Add(Note(user));
   panel.Children.Add(Action("Copy contact ID",()=>Copy_Click(this,new RoutedEventArgs())));
   var status=new ListBox{ItemsSource=new[]{"Online","Away","Do not disturb"},SelectedIndex=LocalStatus.SelectedIndex,Margin=new Thickness(0,8,0,0)};
   status.SelectionChanged+=(_,_)=>LocalStatus.SelectedIndex=status.SelectedIndex;
   panel.Children.Add(status);
   w.Content=panel;w.ShowDialog();return;
  }
  AdjustProfile();
 }
 void Tint(Button? b,bool on){if(b==null)return;b.Background=on?Ink("#24210E"):Brushes.Transparent;b.Foreground=on?Ink("#FFD500"):Ink("#B7BAC4");}
 void UpdateNavigation(bool? pending){
  if(FriendsNav==null||RequestsNav==null)return;
  Tint(FriendsNav,pending==false);Tint(RequestsNav,pending==true);
  Tint(TabAll,pending==false);Tint(TabPending,pending==true);
  HomeTile.Tag=pending==null?"":"Active";
 }
 void UpdateRequestBadge(){
  if(RequestsBadge==null)return;
  int n=(Rooms.ItemsSource as IEnumerable<Room>)?.Count(r=>!r.accepted&&r.peer==user)??0;
  RequestsBadge.Visibility=n>0?Visibility.Visible:Visibility.Collapsed;
  RequestsBadgeText.Text=n>99?"99+":n.ToString();
 }
 void UpdateProfile(JsonElement session){
  ApplyAccountProfile(session.GetProperty("user"));
 }
 void ApplyAccountProfile(JsonElement account){
  var label=Identity.Text.Split('@')[0];
  if(account.TryGetProperty("user_metadata",out var meta)&&meta.ValueKind==JsonValueKind.Object&&meta.TryGetProperty("display_name",out var dn)&&dn.ValueKind==JsonValueKind.String&&!string.IsNullOrWhiteSpace(dn.GetString()))label=dn.GetString()!;
  if(string.IsNullOrWhiteSpace(label))label="Volt user";
  DisplayName.Text=ProfileName.Text=label;
  AvatarLetter.Text=ProfileAvatarLetter.Text=label[..1].ToUpperInvariant();
  ProfileEmail.Text=Identity.Text;ProfileId.Text=user;ProfileId.ToolTip=user;Identity.ToolTip=Identity.Text;
  avatarData=account.TryGetProperty("user_metadata",out var md)&&md.ValueKind==JsonValueKind.Object&&md.TryGetProperty("volt_avatar",out var av)&&av.ValueKind==JsonValueKind.String?av.GetString()??"":"";
  ApplyAvatar(UserAvatarBorder,AvatarLetter,avatarData);ApplyAvatar(ProfileAvatarBorder,ProfileAvatarLetter,avatarData);
  AdjustProfile();
 }
 void LocalStatus_Changed(object s,SelectionChangedEventArgs e){
  if(LocalStatusText==null||LocalStatusDot==null||LocalStatus==null||LocalStatus.SelectedIndex<0)return;
  var i=LocalStatus.SelectedIndex;
  LocalStatusText.Text=new[]{"Online (local)","Away (local)","Do not disturb (local)"}[i];
  LocalStatusDot.Fill=Ink(new[]{"#23A55A","#F0B232","#F23F43"}[i]);
  prefs.StatusIndex=i;
  if(IsLoaded)try{prefs.Save();}catch{}
 }
}
