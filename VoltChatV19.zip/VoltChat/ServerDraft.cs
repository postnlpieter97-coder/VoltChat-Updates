using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace VoltChat;
public partial class MainWindow
{
    (string name,string description,string template)? ServerDraft(Window owner)
    {
        var w=new Window{Owner=owner,Title="Create a server",Width=460,SizeToContent=SizeToContent.Height,ResizeMode=ResizeMode.NoResize,WindowStartupLocation=WindowStartupLocation.CenterOwner,Background=Ink("#111111"),Foreground=Brushes.White};
        var p=new StackPanel{Margin=new Thickness(24)};w.Content=p;
        p.Children.Add(Heading("Create your server",24));p.Children.Add(Note("Private, invitation-only spaces for people you know."));
        p.Children.Add(Note("Template"));var templates=new ComboBox{ItemsSource=new[]{"Custom","Gaming","Community","Friends","School"},SelectedIndex=0,Margin=new Thickness(0,0,0,12)};p.Children.Add(templates);
        p.Children.Add(Note("Server name"));var name=new TextBox{MaxLength=80,Style=(Style)FindResource(typeof(TextBox))};p.Children.Add(name);
        p.Children.Add(Note("Description (optional)"));var desc=new TextBox{MaxLength=500,AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,Height=80,Style=(Style)FindResource(typeof(TextBox))};p.Children.Add(desc);
        var error=Note("");p.Children.Add(error);var ok=Action("Create server",()=>{if(string.IsNullOrWhiteSpace(name.Text)){error.Text="Enter a server name.";return;}w.DialogResult=true;},true);ok.IsDefault=true;p.Children.Add(ok);var cancel=Action("Cancel",()=>w.DialogResult=false);cancel.IsCancel=true;p.Children.Add(cancel);w.Loaded+=(_,_)=>name.Focus();
        return w.ShowDialog()==true?(name.Text.Trim(),desc.Text.Trim(),(string)templates.SelectedItem):null;
    }
}
