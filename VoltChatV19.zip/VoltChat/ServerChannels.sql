-- Run after PrivateSpaces.sql. Preserves existing accounts, servers and messages.
begin;
create table if not exists public.volt_channels (
 id uuid primary key default gen_random_uuid(), space_id uuid not null references public.volt_spaces(id) on delete cascade,
 name text not null check (length(trim(name)) between 1 and 80), kind text not null check(kind in ('text','announcement','voice')),
 unique(space_id,name), unique(space_id,id));
alter table public.volt_channels enable row level security;
revoke all on public.volt_channels from anon, authenticated;
grant select,delete on public.volt_channels to authenticated;
grant insert(space_id,name,kind),update(name) on public.volt_channels to authenticated;
create policy vc_read on public.volt_channels for select to authenticated using (exists(select 1 from public.volt_spaces s where s.id=space_id and (s.owner=auth.uid() or exists(select 1 from public.volt_space_members m where m.space_id=s.id and m.member=auth.uid() and m.accepted))));
create policy vc_insert on public.volt_channels for insert to authenticated with check(exists(select 1 from public.volt_spaces s where s.id=space_id and s.owner=auth.uid()));
create policy vc_update on public.volt_channels for update to authenticated using(name<>'general' and exists(select 1 from public.volt_spaces s where s.id=space_id and s.owner=auth.uid())) with check(exists(select 1 from public.volt_spaces s where s.id=space_id and s.owner=auth.uid()));
-- No channel deletion until history retention and moderation workflow are implemented.
revoke delete on public.volt_channels from authenticated;
alter table public.volt_spaces add column if not exists description text not null default '' check(length(description)<=500);
alter table public.volt_spaces add column if not exists template text not null default 'Custom' check(template in ('Custom','Gaming','Community','Friends','School'));
grant insert(description,template) on public.volt_spaces to authenticated;
insert into public.volt_channels(space_id,name,kind) select s.id,v.name,v.kind from public.volt_spaces s cross join (values ('general','text'),('announcements','announcement'),('General Voice','voice')) v(name,kind) on conflict(space_id,name) do nothing;
create function public.volt_seed_channels() returns trigger language plpgsql security invoker set search_path='' as $$ begin
 insert into public.volt_channels(space_id,name,kind) values(new.id,'general','text'),(new.id,'announcements','announcement'),(new.id,'General Voice','voice'); return new; end $$;
revoke execute on function public.volt_seed_channels() from public,anon,authenticated;
create trigger volt_seed_channels after insert on public.volt_spaces for each row execute function public.volt_seed_channels();
alter table public.volt_space_messages add column if not exists channel_id uuid;
update public.volt_space_messages m set channel_id=c.id from public.volt_channels c where c.space_id=m.space_id and c.name='general' and m.channel_id is null;
alter table public.volt_space_messages add constraint volt_message_channel_fk foreign key(space_id,channel_id) references public.volt_channels(space_id,id);
alter table public.volt_space_messages alter column channel_id set not null;
grant insert(channel_id) on public.volt_space_messages to authenticated;
-- Existing RLS still enforces accepted membership and sender identity. Add channel-type restriction.
create policy vc_message_kind on public.volt_space_messages as restrictive for insert to authenticated with check(exists(select 1 from public.volt_channels c join public.volt_spaces s on s.id=c.space_id where c.id=channel_id and c.space_id=volt_space_messages.space_id and (c.kind='text' or (c.kind='announcement' and s.owner=auth.uid()))));
create index if not exists volt_channel_history on public.volt_space_messages(channel_id,created_at desc);
-- Compatibility for older V14 clients: assign general on legacy message inserts.
create function public.volt_default_message_channel() returns trigger language plpgsql security invoker set search_path='' as $$ begin if new.channel_id is null then select id into new.channel_id from public.volt_channels where space_id=new.space_id and name='general'; end if; return new; end $$;
revoke execute on function public.volt_default_message_channel() from public,anon,authenticated;
create trigger volt_default_message_channel before insert on public.volt_space_messages for each row execute function public.volt_default_message_channel();
commit;
