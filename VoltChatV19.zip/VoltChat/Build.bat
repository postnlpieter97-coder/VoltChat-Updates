@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1 || (echo Install .NET 8 SDK from https://dotnet.microsoft.com/download/dotnet/8.0 & pause & exit /b 1)
dotnet publish VoltChat.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o Output > build.log 2>&1
if errorlevel 1 (type build.log & pause & exit /b 1)
if not exist "Output\VoltChat.exe" (echo Build failed: EXE missing. & pause & exit /b 1)
echo Built Output\VoltChat.exe
explorer "%~dp0Output"
pause
