using System.IO;
using System.Runtime.InteropServices;
using System.Text;
namespace VoltChat;
internal static class SessionStore
{
    static readonly string PathName=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"VoltChat","session.dat");
    [StructLayout(LayoutKind.Sequential)] struct Blob { public int Size; public IntPtr Data; }
    [DllImport("crypt32.dll",SetLastError=true)] [return:MarshalAs(UnmanagedType.Bool)] static extern bool CryptProtectData(ref Blob input,IntPtr description,IntPtr entropy,IntPtr reserved,IntPtr prompt,uint flags,out Blob output);
    [DllImport("crypt32.dll",SetLastError=true)] [return:MarshalAs(UnmanagedType.Bool)] static extern bool CryptUnprotectData(ref Blob input,IntPtr description,IntPtr entropy,IntPtr reserved,IntPtr prompt,uint flags,out Blob output);
    [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr ptr);
    static byte[] Transform(byte[] bytes,bool protect){var input=new Blob{Size=bytes.Length,Data=Marshal.AllocHGlobal(bytes.Length)};Blob output=default;try{Marshal.Copy(bytes,0,input.Data,bytes.Length);bool ok=protect?CryptProtectData(ref input,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,1,out output):CryptUnprotectData(ref input,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,1,out output);if(!ok)throw new System.ComponentModel.Win32Exception();var result=new byte[output.Size];Marshal.Copy(output.Data,result,0,result.Length);return result;}finally{Marshal.FreeHGlobal(input.Data);if(output.Data!=IntPtr.Zero)LocalFree(output.Data);}}
    public static void Save(string token){Directory.CreateDirectory(Path.GetDirectoryName(PathName)!);File.WriteAllBytes(PathName+".tmp",Transform(Encoding.UTF8.GetBytes(token),true));File.Move(PathName+".tmp",PathName,true);}
    public static string? Load()=>File.Exists(PathName)?Encoding.UTF8.GetString(Transform(File.ReadAllBytes(PathName),false)):null;
    public static void Clear(){File.Delete(PathName);File.Delete(PathName+".tmp");}
}
