using System.Net.Http;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
namespace VoltChat;
public partial class MainWindow
{
    string? railOpenId;
    string railSignature="";
    void UpdateRailSelection(){foreach(var tile in ServerRail.Children.OfType<Button>())tile.Tag=Equals(tile.DataContext,activeServerId)?"Active":"";}
    async Task RefreshServerRail(){
        try{
            var rows=(await Request("/rest/v1/volt_spaces?select=id,owner,name&order=name",HttpMethod.Get)).Deserialize<List<Space>>()??new();
            var signature=JsonSerializer.Serialize(rows);if(signature==railSignature)return;
            ServerRail.Children.Clear();
            foreach(var sp in rows){
                var title=sp.name.Trim();var label=string.Concat(title.Split(' ',StringSplitOptions.RemoveEmptyEntries).Take(2).Select(x=>x[..1].ToUpperInvariant()));
                var button=new Button{Style=(Style)FindResource("ServerTile"),Content=label.Length==0?"V":label,ToolTip=sp.name,Tag="",DataContext=sp.id};
                System.Windows.Automation.AutomationProperties.SetName(button,"Open server "+sp.name);
                button.Click+=(_,_)=>{if(busy){Status.Text="Refresh in progress. Try again in a moment.";return;}foreach(var tile in ServerRail.Children.OfType<Button>())tile.Tag=ReferenceEquals(tile,button)?"Active":"";railOpenId=sp.id;Spaces_Click(button,new RoutedEventArgs());};
                ServerRail.Children.Add(button);
            }
            railSignature=signature;UpdateRailSelection();
        }catch(Exception ex){ServerRail.ToolTip="Unable to load servers: "+ex.Message;}
    }
    async void CreateServerRail_Click(object sender,RoutedEventArgs e){
        string? created=null;
        await Guard(async()=>{
            var draft=ServerDraft(this);if(draft==null)return;var name=draft.Value.name;
            if(name.Length<1||name.Length>80)throw new Exception("Choose a name between 1 and 80 characters.");
            var before=(await Request("/rest/v1/volt_spaces?select=id,owner,name",HttpMethod.Get)).Deserialize<List<Space>>()??new();
            await Request("/rest/v1/volt_spaces",HttpMethod.Post,new{owner=user,name,description=draft.Value.description,template=draft.Value.template});
            var after=(await Request("/rest/v1/volt_spaces?select=id,owner,name",HttpMethod.Get)).Deserialize<List<Space>>()??new();
            created=after.FirstOrDefault(a=>a.owner==user&&a.name==name&&!before.Any(b=>b.id==a.id))?.id;
            await RefreshServerRail();Status.Text="Server created.";
        });
        if(created!=null){railOpenId=created;Spaces_Click(this,new RoutedEventArgs());}
    }
}
