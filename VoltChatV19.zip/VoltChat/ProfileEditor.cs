using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
namespace VoltChat;
public partial class MainWindow {
 string avatarData="";
 static BitmapImage? DecodeAvatar(string data){try{if(data.Length>16000||data.Length==0)return null;using var stream=new MemoryStream(Convert.FromBase64String(data));var image=new BitmapImage();image.BeginInit();image.CacheOption=BitmapCacheOption.OnLoad;image.DecodePixelWidth=128;image.StreamSource=stream;image.EndInit();image.Freeze();return image;}catch{return null;}}
 void ApplyAvatar(Border border,TextBlock letter,string data){var image=DecodeAvatar(data);border.Background=image==null?Ink("#FFD500"):new ImageBrush(image){Stretch=Stretch.UniformToFill};letter.Visibility=image==null?Visibility.Visible:Visibility.Collapsed;}
 static string ReadAvatar(string path){var info=new FileInfo(path);if(info.Length>8*1024*1024)throw new Exception("Choose an image smaller than 8 MB.");using var stream=File.OpenRead(path);var bitmap=new BitmapImage();bitmap.BeginInit();bitmap.CacheOption=BitmapCacheOption.OnLoad;bitmap.DecodePixelWidth=128;bitmap.StreamSource=stream;bitmap.EndInit();double factor=Math.Min(128.0/bitmap.PixelWidth,128.0/bitmap.PixelHeight);var resized=new TransformedBitmap(bitmap,new ScaleTransform(factor,factor));foreach(int quality in new[]{80,60,40,20}){var encoder=new JpegBitmapEncoder{QualityLevel=quality};encoder.Frames.Add(BitmapFrame.Create(resized));using var output=new MemoryStream();encoder.Save(output);var data=Convert.ToBase64String(output.ToArray());if(data.Length<=16000)return data;}throw new Exception("Image could not be compressed. Choose another image.");}
 void DrawProfileEditor(StackPanel page,Window window){
  page.Children.Add(Note("Your display name and profile picture are saved to your account. Your login email stays unchanged."));
  string pending=avatarData;
  var letter=new TextBlock{Text=DisplayName.Text.Length>0?DisplayName.Text[..1].ToUpperInvariant():"V",Foreground=Ink("#090909"),FontSize=30,FontWeight=FontWeights.Bold,HorizontalAlignment=HorizontalAlignment.Center,VerticalAlignment=VerticalAlignment.Center};
  var preview=new Border{Width=88,Height=88,CornerRadius=new CornerRadius(44),HorizontalAlignment=HorizontalAlignment.Left,Child=letter,Margin=new Thickness(0,0,0,12)};page.Children.Add(preview);ApplyAvatar(preview,letter,pending);
  var status=Note("");
  page.Children.Add(Action("Change profile picture",()=>{var picker=new OpenFileDialog{Filter="Images (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp"};if(picker.ShowDialog(window)!=true)return;try{pending=ReadAvatar(picker.FileName);ApplyAvatar(preview,letter,pending);status.Text="Picture ready to save.";}catch(Exception ex){status.Text=ex.Message;}}));
  page.Children.Add(Action("Remove picture",()=>{pending="";ApplyAvatar(preview,letter,pending);status.Text="Save changes to remove your picture.";}));
  page.Children.Add(Note("DISPLAY NAME"));var name=new TextBox{Text=DisplayName.Text,MaxLength=32,Margin=new Thickness(0,0,0,12),MinHeight=36,Padding=new Thickness(8),Background=Ink("#111111"),Foreground=Brushes.White,BorderBrush=Ink("#303030")};System.Windows.Automation.AutomationProperties.SetName(name,"Display name");page.Children.Add(name);name.TextChanged+=(_,_)=>letter.Text=name.Text.Trim().Length>0?name.Text.Trim()[..1].ToUpperInvariant():"V";
  var save=new Button{Content="Save profile",Style=(Style)FindResource("PrimaryButtonStyle"),HorizontalAlignment=HorizontalAlignment.Left,MinWidth=140,Margin=new Thickness(0,4,0,8)};page.Children.Add(save);page.Children.Add(status);
  save.Click+=async(_,_)=>{if(busy){status.Text="Please try again in a moment.";return;}var value=name.Text.Trim();if(value.Length<1||value.Length>32||value.Any(char.IsControl)){status.Text="Enter a display name of 1–32 characters.";return;}busy=true;save.IsEnabled=false;status.Text="Saving profile…";try{var account=await Request("/auth/v1/user",HttpMethod.Put,new{data=new{display_name=value,volt_avatar=pending}});ApplyAccountProfile(account);status.Text="Profile saved.";}catch(Exception ex){status.Text=ex.Message;}finally{busy=false;save.IsEnabled=true;}};
 }
}
