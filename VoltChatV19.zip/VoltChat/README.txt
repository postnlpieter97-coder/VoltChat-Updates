V14 — Visual overhaul (GUI only)
No backend, SQL, login or messaging logic changed. Build.bat is unchanged. Apply nothing in Supabase.
New: shared theme in Theme.xaml (one palette, one set of controls used by the main window, settings, dialogs and server window); rebuilt login screen; rebuilt server rail with active pill indicator; sidebar with search, navigation rows and a pending-requests badge; conversation header with private-chat subtitle; rounded composer with focus ring and send button; friends view with tab pills, contact cards with status chips and a profile card (banner, status list, copyable contact ID); toggle switches instead of checkboxes; slim scrollbars; dark context menus and tooltips; dark Windows title bar on every window (Theme.cs).
Window frame now uses WindowChrome (fixes the white line at the top and the stray outline on the minimize button). Keyboard focus rings only appear when navigating with the keyboard.
Not tested here: Windows compilation and runtime. If maximizing looks offset on your machine, remove the StateChanged line in Redesign.cs. Design/tokens.css was updated to the same palette.

V12: Solid window, server shortcuts in the left rail, direct create button, compact button styles and custom sliders. Server shortcuts open the existing private server window. Existing V9 SQL must already be installed. Do not rerun it if installed. Windows build not tested here.

VOLT CHAT V10 — GLASS EDITION

Extract to a new folder and run Build.bat. Open Output\VoltChat.exe.
Settings > Appearance > Window opacity changes transparency (85–100%). 100% is fully opaque. The opacity applies to the entire main window, including text; not a native acrylic blur. The layered WPF window may use more graphics resources than the previous opaque version.
New conversation opens a direct contact-ID dialog. Private servers remain invite-only. Existing Supabase, email verification and remembered-login logic are retained. If PrivateSpaces.sql was already run, do not run it again. If not, follow the V9 private server setup below.
No Windows compilation or runtime test performed in this environment.

VOLT CHAT V7 — Connect Beyond Limits.
Windows 10/11 • .NET 8 WPF

UPGRADE
1. Extract into a new folder. Keep your V6 backup.
2. Run Build.bat on Windows with the .NET 8 SDK installed.
3. Open Output\VoltChat.exe. Existing accounts and messages are unchanged.
4. To enable in-app password reset, open Supabase Authentication > Email Templates > Reset password. Copy RecoveryEmail.html into the body and save. Keep OTP length at six. Confirm signup continues using your existing template. No localhost link is required for this code-based flow.
5. Do NOT rerun Database.sql on an existing database. No migration required for these changes.
6. Verify password recovery, normal login, signup and private messaging with two consenting test accounts before distribution.

WHAT IS IMPLEMENTED IN V7 SOURCE
V6 dark/yellow interface and hover animations, login/signup, email OTP verification, in-memory session refresh, existing Supabase REST conversations, invitation acceptance, polling (8 seconds), sending, blocking and reporting.
New: code-based password recovery, copy/report context menu, search loaded messages, load up to 1,000 messages (100 at a time), blocked contact list and unblock, message font size setting (session only), F11 maximize toggle, resizable conversation sidebar. Registration text no longer promises email delivery on repeated signup.

NOT IMPLEMENTED
True Supabase Realtime sockets; new friends/profile/presence system; group chat; WebRTC calls, video or sharing; read receipts, typing, edit/delete/forward/reactions/pins, uploads/GIF/stickers, link previews, markdown; persistent login, 2FA, email changes or account deletion; notifications/tray, all requested settings and themes, virtualized history, installer or signed automatic updates. No fake users or simulated calls. Existing message history is not end-to-end encrypted. Do not use for sensitive communications.

SECURITY
Only publishable Supabase key in the client. No SMTP keys, service role keys or plaintext passwords stored. Existing RLS and invitation checks preserved. No live backend changes made. Review existing policies, rate limits, report handling and abuse controls before public release. WebRTC deployment needs consent-based capture, authenticated signaling and properly secured STUN/TURN; free infrastructure is not guaranteed.

TEST STATUS
XAML XML parsing and event-handler name checks performed; Windows compilation, runtime behavior, and live authentication are not tested in this environment. If Build.bat fails, inspect build.log. Startup crash log: %TEMP%\VoltChat-startup.log.

V8: Refined inbox, visible search labels, actionable empty state, composer hidden until an accepted conversation is selected. Remember login saves only the refresh token via Windows DPAPI (current Windows user) in LocalAppData. Sign out clears the cache. Only enable on a trusted device. No database migrations required. Windows compilation and live restoration have not been tested here.

V9: Dedicated categorized settings window, persisted device preferences, private invite-only servers (single group conversation per server), member invitations/acceptance, leave/remove, group messages, edit/delete own group messages and reports. No public discovery or channels. Existing DMs and authentication unchanged. Apply PrivateSpaces.sql ONCE in Supabase SQL Editor after backing up; do not rerun Database.sql. SQL has not been applied to the live project. Group refresh uses polling, not Realtime. Administrators must review volt_space_reports. Test RLS with owner, pending member, accepted member, blocked user and unrelated user before distribution. No voice/video, full profiles, friend graph, attachments, public servers, extra themes, notifications, 2FA or automatic updates in this release. Windows compile and live DB tests required.

V11: Home and pending contact views; private server creation automatically selects the new server. Existing V9 SQL tables are required. No new migration. No live presence or fake profiles. Windows build not tested.

V13 — Clean home screen
Build.bat is unchanged. No new SQL migration. Existing V12 backend and session restoration preserved.
Design/index.html is a standalone front-end reference, with CSS tokens in Design/tokens.css. It is not the live client. Local status is explicitly local, not network presence. No mic or headphone buttons are added until voice functionality exists. Native settings remain in the bottom user bar only. Native display name uses existing display_name metadata if present, otherwise the email prefix. The WPF design collapses the profile at small widths; the profile button opens a dialog there. No public community discovery. Static XML and archive checks only; Windows runtime testing remains required.
