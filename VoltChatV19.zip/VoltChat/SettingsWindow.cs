using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Input;
namespace VoltChat;
public sealed class ClientPreferences
{
    public bool CheckUpdates {get;set;}=true;
    public int StatusIndex {get;set;}=0;
    public double GlassOpacity {get;set;}=1;
    public double FontSize {get;set;}=14;
    public double Scale {get;set;}=1;
    public bool Avatars {get;set;}=true;
    public bool Timestamps {get;set;}=true;
    public bool Compact {get;set;}=false;
    public bool Animations {get;set;}=true;
    public bool SpellCheck {get;set;}=false;
    public bool RememberWindow {get;set;}=true;
    public double Width {get;set;}=1280;
    public double Height {get;set;}=800;
    public string Accent {get;set;}="#FFD500";
    static string FileName=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"VoltChat","preferences.json");
    public static ClientPreferences Load(){try{return JsonSerializer.Deserialize<ClientPreferences>(File.ReadAllText(FileName))??new();}catch{return new();}}
    public void Save(){Directory.CreateDirectory(Path.GetDirectoryName(FileName)!);File.WriteAllText(FileName+".tmp",JsonSerializer.Serialize(this));File.Move(FileName+".tmp",FileName,true);}
}
public partial class MainWindow
{
    ClientPreferences prefs=new();
    void InitPreferences(){prefs=ClientPreferences.Load();messageFont=Math.Clamp(prefs.FontSize,11,22);if(prefs.RememberWindow&&double.IsFinite(prefs.Width)&&double.IsFinite(prefs.Height)){Width=Math.Clamp(prefs.Width,MinWidth,Math.Max(MinWidth,SystemParameters.WorkArea.Width));Height=Math.Clamp(prefs.Height,MinHeight,Math.Max(MinHeight,SystemParameters.WorkArea.Height));}ApplyPreferences();Closing+=(_,_)=>{try{if(WindowState==WindowState.Normal){prefs.Width=Width;prefs.Height=Height;}prefs.Save();}catch{}};}
    void ApplyPreferences(){Opacity=1;prefs.GlassOpacity=1;messageFont=Math.Clamp(prefs.FontSize,11,22);ChatPanel.LayoutTransform=new ScaleTransform(Math.Clamp(prefs.Scale,.85,1.15),Math.Clamp(prefs.Scale,.85,1.15));SpellCheck.SetIsEnabled(Message,prefs.SpellCheck);foreach(var card in Messages.Children.OfType<Border>()){card.Padding=new Thickness(10,prefs.Compact?3:8,10,prefs.Compact?3:8);if(card.Child is Grid g){if(g.Children.OfType<Border>().FirstOrDefault() is Border a)a.Visibility=prefs.Avatars?Visibility.Visible:Visibility.Hidden;if(g.Children.OfType<StackPanel>().FirstOrDefault() is StackPanel st){if(st.Children.Count>1&&st.Children[1] is TextBlock body)body.FontSize=messageFont;if(st.Children[0] is StackPanel h&&h.Children.Count>1)h.Children[1].Visibility=prefs.Timestamps?Visibility.Visible:Visibility.Collapsed;}}}}
    static SolidColorBrush Ink(string hex)=>new((Color)ColorConverter.ConvertFromString(hex));
    TextBlock Heading(string text,int size=24)=>new(){Text=text,FontSize=size,FontWeight=FontWeights.SemiBold,Foreground=Brushes.White,Margin=new Thickness(0,0,0,14)};
    TextBlock Note(string text)=>new(){Text=text,Foreground=Ink("#9A9EAB"),TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,4,0,12)};
    Button Action(string name,System.Action action,bool primary=false){var b=new Button{Content=name,Style=(Style)FindResource(primary?"PrimaryButtonStyle":"SecondaryButtonStyle"),HorizontalAlignment=HorizontalAlignment.Left,MinWidth=140,Margin=new Thickness(0,4,0,8)};b.Click+=(_,_)=>action();return b;}
    Grid? settingsOverlay;
    IInputElement? settingsPreviousFocus;
    bool settingsClosing;
    void CloseSettings(bool animate=true){
        var overlay=settingsOverlay;if(overlay==null||settingsClosing)return;
        settingsClosing=true;
        void finish(){WindowFrame.Children.Remove(overlay);settingsOverlay=null;settingsClosing=false;ChatPanel.IsEnabled=true;if(settingsPreviousFocus is UIElement element&&element.IsVisible&&element.IsEnabled)element.Focus();settingsPreviousFocus=null;}
        if(animate&&prefs.Animations){var fade=new DoubleAnimation(1,0,TimeSpan.FromMilliseconds(140));fade.Completed+=(_,_)=>finish();overlay.BeginAnimation(UIElement.OpacityProperty,fade);}else finish();
    }
    void Settings_Click(object s,RoutedEventArgs e){
        if(settingsOverlay!=null||ChatPanel.Visibility!=Visibility.Visible)return;
        OptionsPanel.Visibility=Visibility.Collapsed;
        settingsPreviousFocus=Keyboard.FocusedElement;
        var overlay=new Grid{Background=Ink("#99000000"),Focusable=true};
        Grid.SetRow(overlay,1);Panel.SetZIndex(overlay,90);
        KeyboardNavigation.SetTabNavigation(overlay,KeyboardNavigationMode.Cycle);
        KeyboardNavigation.SetControlTabNavigation(overlay,KeyboardNavigationMode.Cycle);
        overlay.PreviewKeyDown+=(_,args)=>{if(args.Key==Key.Escape){args.Handled=true;CloseSettings();}};
        var shell=new Border{Background=Ink("#171717"),BorderBrush=Ink("#404040"),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(16),Margin=new Thickness(28,22,28,26),MaxWidth=1000,MaxHeight=730,HorizontalAlignment=HorizontalAlignment.Stretch,VerticalAlignment=VerticalAlignment.Stretch,RenderTransformOrigin=new Point(.5,.5),Effect=new DropShadowEffect{Color=Colors.Black,BlurRadius=36,ShadowDepth=12,Direction=270,Opacity=.85}};
        var transform=new TransformGroup();var scale=new ScaleTransform(1,1);var shift=new TranslateTransform(0,0);transform.Children.Add(scale);transform.Children.Add(shift);shell.RenderTransform=transform;
        var frame=new DockPanel{LastChildFill=true};shell.Child=frame;
        var titleBar=new Border{Background=Ink("#202020"),CornerRadius=new CornerRadius(15,15,0,0),Padding=new Thickness(16,8,10,8),BorderBrush=Ink("#303030"),BorderThickness=new Thickness(0,0,0,1)};
        var header=new DockPanel();titleBar.Child=header;
        var close=Action("Close  ×",()=>CloseSettings());close.MinWidth=72;close.Margin=new Thickness(0);DockPanel.SetDock(close,Dock.Right);header.Children.Add(close);System.Windows.Automation.AutomationProperties.SetName(close,"Close settings");close.ToolTip="Close settings (Esc)";
        header.Children.Add(new TextBlock{Text="Volt Chat  /  Settings",Foreground=Brushes.White,FontWeight=FontWeights.SemiBold,VerticalAlignment=VerticalAlignment.Center});DockPanel.SetDock(titleBar,Dock.Top);frame.Children.Add(titleBar);
        var root=new Grid();root.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(210)});root.ColumnDefinitions.Add(new ColumnDefinition());var rail=new DockPanel{Background=Ink("#111111")};root.Children.Add(rail);var brand=new TextBlock{Text="VOLT CHAT  /  SETTINGS",Foreground=Ink("#FFD500"),FontWeight=FontWeights.Bold,Margin=new Thickness(22,26,10,20)};DockPanel.SetDock(brand,Dock.Top);rail.Children.Add(brand);var done=Action("Done",()=>CloseSettings(),true);done.Margin=new Thickness(14,8,14,18);done.HorizontalAlignment=HorizontalAlignment.Stretch;DockPanel.SetDock(done,Dock.Bottom);rail.Children.Add(done);var nav=new StackPanel{Margin=new Thickness(14,0,14,12)};rail.Children.Add(new ScrollViewer{Content=nav,VerticalScrollBarVisibility=ScrollBarVisibility.Auto});var page=new StackPanel{Margin=new Thickness(32,24,32,24)};var content=new ScrollViewer{Content=page,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};Grid.SetColumn(content,1);root.Children.Add(content);root.Background=Ink("#171717");frame.Children.Add(root);overlay.Children.Add(shell);settingsOverlay=overlay;WindowFrame.Children.Add(overlay);ChatPanel.IsEnabled=false;
      void save(){try{prefs.Save();ApplyPreferences();}catch(Exception ex){MessageBox.Show(this,ex.Message,"Settings");}}
      void section(string name){nav.Children.Add(new TextBlock{Text=name,Foreground=Ink("#9A9EAB"),FontSize=11,FontWeight=FontWeights.SemiBold,Margin=new Thickness(9,18,0,6)});}
      Button? active=null;
      void tab(string title,System.Action draw){var b=Action(title,()=>{});b.Click+=(_,_)=>{if(active!=null){active.Background=Brushes.Transparent;active.Foreground=Ink("#B7BAC4");}active=b;b.Background=Ink("#24210E");b.Foreground=Ink("#FFD500");page.Children.Clear();page.Children.Add(Heading(title));draw();content.ScrollToTop();FadeIn(page);};b.Style=(Style)FindResource("Flat");b.HorizontalAlignment=HorizontalAlignment.Stretch;b.HorizontalContentAlignment=HorizontalAlignment.Left;nav.Children.Add(b);}
      void text(string value)=>page.Children.Add(Note(value));
      void toggle(string label,bool value,System.Action<bool> set){var c=new CheckBox{Content=label,Foreground=Brushes.White,IsChecked=value,Margin=new Thickness(0,10,0,12)};c.Checked+=(_,_)=>{set(true);save();};c.Unchecked+=(_,_)=>{set(false);save();};page.Children.Add(c);}
      void slider(string label,double value,double min,double max,double step,System.Action<double> set){var valueLabel=Note(label+"  •  "+value.ToString("0.##"));page.Children.Add(valueLabel);var sl=new Slider{Style=(Style)FindResource("CleanSlider"),Minimum=min,Maximum=max,Value=value,TickFrequency=step,IsSnapToTickEnabled=true,MaxWidth=320,HorizontalAlignment=HorizontalAlignment.Stretch,Margin=new Thickness(0,0,0,18)};sl.ValueChanged+=(_,_)=>{valueLabel.Text=label+"  •  "+sl.Value.ToString("0.##");set(sl.Value);save();};page.Children.Add(sl);}
      void account(){text("Signed in as");page.Children.Add(Heading(Identity.Text,18));DrawProfileEditor(page,this);text("Passwords are never stored. Sign out and use Forgot password to change your password through email.");page.Children.Add(Action("Sign out",()=>{CloseSettings(false);Logout_Click(this,new RoutedEventArgs());}));}
      section("USER SETTINGS");tab("My Account",account);tab("Privacy & Safety",()=>{text("Manage blocked contacts and report inappropriate messages from their context menu. Messages are not end-to-end encrypted.");page.Children.Add(Action("Blocked users",()=>{CloseSettings(false);BlockedContacts_Click(this,new RoutedEventArgs());}));});tab("Devices",()=>{text("Remembered sessions are encrypted using Windows DPAPI. Sign out to remove this device’s stored session.");page.Children.Add(Action("Forget saved login",()=>{try{SessionStore.Clear();RememberLogin.IsChecked=false;text("Saved login removed.");}catch(Exception ex){text(ex.Message);}}));});
      section("APP SETTINGS");tab("Appearance",()=>{text("Personalize your workspace. Changes save automatically.");slider("Chat font size",prefs.FontSize,11,22,1,v=>prefs.FontSize=v);slider("Interface scale",prefs.Scale,.85,1.15,.05,v=>prefs.Scale=v);toggle("Compact messages",prefs.Compact,v=>prefs.Compact=v);toggle("Show avatars",prefs.Avatars,v=>prefs.Avatars=v);toggle("Show timestamps",prefs.Timestamps,v=>prefs.Timestamps=v);toggle("Enable screen transitions",prefs.Animations,v=>prefs.Animations=v);text("Theme: Volt Yellow • charcoal and electric yellow");});tab("Accessibility",()=>{toggle("Reduce motion (screen transitions)",!prefs.Animations,v=>prefs.Animations=!v);slider("Message text size",prefs.FontSize,11,22,1,v=>prefs.FontSize=v);});tab("Text & Images",()=>toggle("Spell check in message composer",prefs.SpellCheck,v=>prefs.SpellCheck=v));tab("Keybinds",()=>{text("Enter — Send message\nF11 — Maximize or restore window\nTab / Shift+Tab — Navigate controls");});tab("Windows Settings",()=>toggle("Remember window size",prefs.RememberWindow,v=>prefs.RememberWindow=v));tab("Advanced",()=>{page.Children.Add(Action("Reset local preferences",()=>{if(MessageBox.Show(this,"Reset your local preferences?","Volt Chat",MessageBoxButton.YesNo)==MessageBoxResult.Yes){prefs=new();save();CloseSettings(false);}}));});section("APPLICATION INFORMATION");tab("Updates",()=>DrawUpdates(page,this));tab("About Volt Chat",()=>{page.Children.Add(Heading("Volt Chat V19",20));text("Connect Beyond Limits.\nPrivate conversations and invite-only spaces.");});if(nav.Children.OfType<Button>().FirstOrDefault() is Button initial){initial.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));initial.Focus();}else close.Focus();
        if(prefs.Animations){var duration=TimeSpan.FromMilliseconds(230);var ease=new QuadraticEase{EasingMode=EasingMode.EaseOut};overlay.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(0,1,duration){EasingFunction=ease});scale.BeginAnimation(ScaleTransform.ScaleXProperty,new DoubleAnimation(.95,1,duration){EasingFunction=ease});scale.BeginAnimation(ScaleTransform.ScaleYProperty,new DoubleAnimation(.95,1,duration){EasingFunction=ease});shift.BeginAnimation(TranslateTransform.YProperty,new DoubleAnimation(12,0,duration){EasingFunction=ease});}}
}
