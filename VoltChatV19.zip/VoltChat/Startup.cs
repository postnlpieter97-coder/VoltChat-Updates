using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
namespace VoltChat;
public partial class MainWindow {
 async Task StartupSequence(){
  if(!prefs.Animations||!SystemParameters.ClientAreaAnimation)return;
  StartupOverlay.Visibility=Visibility.Visible;
  var scale=(ScaleTransform)StartupBolt.RenderTransform;
  var ease=new CubicEase{EasingMode=EasingMode.EaseOut};
  scale.BeginAnimation(ScaleTransform.ScaleXProperty,new DoubleAnimation(.75,1,TimeSpan.FromMilliseconds(450)){EasingFunction=ease});
  scale.BeginAnimation(ScaleTransform.ScaleYProperty,new DoubleAnimation(.75,1,TimeSpan.FromMilliseconds(450)){EasingFunction=ease});
  StartupProgress.BeginAnimation(FrameworkElement.WidthProperty,new DoubleAnimation(0,150,TimeSpan.FromMilliseconds(650)){EasingFunction=ease});
  await Task.Delay(700);
  StartupOverlay.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(1,0,TimeSpan.FromMilliseconds(220)));
  await Task.Delay(240);StartupOverlay.Visibility=Visibility.Collapsed;StartupOverlay.BeginAnimation(UIElement.OpacityProperty,null);
 }
}
