using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
namespace VoltChat;
// Small helper that asks Windows 10/11 to draw dark title bars and borders matching the Volt theme.
// Every call is best-effort: on older Windows versions the attributes are simply ignored.
static class WinChrome
{
    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);
    static int Rgb(byte r, byte g, byte b) => r | (g << 8) | (b << 16);
    public static void Apply(Window window, bool rounded)
    {
        try
        {
            var handle = new WindowInteropHelper(window).Handle;
            if (handle == IntPtr.Zero) return;
            int dark = 1; DwmSetWindowAttribute(handle, 20, ref dark, 4);              // immersive dark mode
            int caption = Rgb(0x13, 0x14, 0x19); DwmSetWindowAttribute(handle, 35, ref caption, 4); // caption colour
            int text = Rgb(0xE4, 0xE6, 0xEB); DwmSetWindowAttribute(handle, 36, ref text, 4);       // caption text
            int border = Rgb(0x2A, 0x2C, 0x35); DwmSetWindowAttribute(handle, 34, ref border, 4);   // border colour
            if (rounded) { int round = 2; DwmSetWindowAttribute(handle, 33, ref round, 4); }          // rounded corners (Win 11)
        }
        catch { }
    }
}
