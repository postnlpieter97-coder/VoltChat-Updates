using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace VoltChat;
public partial class MainWindow
{
    bool pendingHome;
    void Home_Click(object s,RoutedEventArgs e)=>ShowHome(false);
    void Pending_Click(object s,RoutedEventArgs e)=>ShowHome(true);
    void ShowHome(bool pending){if(activeServerId!=null&&busy)return;CloseServerView();if(token!="")timer.Start();pendingHome=pending;UpdateNavigation(pending);OptionsPanel.Visibility=Visibility.Collapsed;HomeView.Visibility=Visibility.Visible;RenderHome();FadeIn(HomeView);}
    void HomeSearch_Changed(object s,TextChangedEventArgs e){if(HomeRows!=null)RenderHome();}
    static TextBlock MakeGlyph(string code,double size,Brush brush)=>new(){Text=code,FontFamily=new FontFamily("Segoe Fluent Icons, Segoe MDL2 Assets"),FontSize=size,Foreground=brush,HorizontalAlignment=HorizontalAlignment.Center,VerticalAlignment=VerticalAlignment.Center};
    void RenderHome(){
        if(HomeRows==null||HomeSearch==null)return;
        HomeRows.Children.Clear();
        var q=HomeSearch.Text.Trim();
        var rows=(Rooms.ItemsSource as IEnumerable<Room>??Enumerable.Empty<Room>())
            .Where(r=>pendingHome?!r.accepted:r.accepted)
            .Where(r=>r.Label.Contains(q,StringComparison.OrdinalIgnoreCase)||(r.owner==user?r.peer:r.owner).Contains(q,StringComparison.OrdinalIgnoreCase))
            .ToList();
        HomeCount.Text=(pendingHome?"PENDING REQUESTS":"ACCEPTED CONTACTS")+" — "+rows.Count;
        HomeAdd.Visibility=rows.Count==0&&!pendingHome&&q.Length==0?Visibility.Collapsed:Visibility.Visible;

        if(rows.Count==0){
            var empty=new StackPanel{HorizontalAlignment=HorizontalAlignment.Center,Margin=new Thickness(12,64,12,0),MaxWidth=360};
            empty.Children.Add(new Border{Width=96,Height=96,CornerRadius=new CornerRadius(48),Background=Ink("#24210E"),BorderBrush=Ink("#5C4F0A"),BorderThickness=new Thickness(1),HorizontalAlignment=HorizontalAlignment.Center,Margin=new Thickness(0,0,0,24),Child=MakeGlyph(q.Length>0?"\uE721":pendingHome?"\uE73E":"\uE716",38,Ink("#FFD500"))});
            empty.Children.Add(new TextBlock{Text=q.Length>0?"No matching contacts":pendingHome?"You’re all caught up":"Start your circle",FontSize=24,FontWeight=FontWeights.Bold,Foreground=Brushes.White,TextAlignment=TextAlignment.Center});
            empty.Children.Add(new TextBlock{Text=q.Length>0?"Try another search.":pendingHome?"New invitations will appear here.":"Add someone you know to start a private conversation.",Foreground=Ink("#9A9EAB"),TextWrapping=TextWrapping.Wrap,TextAlignment=TextAlignment.Center,Margin=new Thickness(0,10,0,22)});
            if(!pendingHome&&q.Length==0){var a=Action("Add contact",()=>Create_Click(this,new RoutedEventArgs()),true);a.HorizontalAlignment=HorizontalAlignment.Center;a.MinWidth=180;a.Padding=new Thickness(16,11,16,11);empty.Children.Add(a);}
            HomeRows.Children.Add(empty);
            return;
        }

        foreach(var r in rows){
            var incoming=!r.accepted&&r.peer==user;
            var card=new Border{CornerRadius=new CornerRadius(12),Padding=new Thickness(14,12,14,12),Margin=new Thickness(0,0,0,8),Background=Ink("#1F2128"),BorderBrush=Ink("#2F323C"),BorderThickness=new Thickness(1)};
            card.MouseEnter+=(_,_)=>{card.Background=Ink("#252831");card.BorderBrush=Ink("#454957");};
            card.MouseLeave+=(_,_)=>{card.Background=Ink("#1F2128");card.BorderBrush=Ink("#2F323C");};
            var row=new DockPanel{LastChildFill=true};

            var open=Action(incoming?"Accept":"Open",async()=>{HomeView.Visibility=Visibility.Collapsed;RoomSearch.Clear();Rooms.SelectedItem=r;await Guard(LoadMessages);if(!r.accepted&&r.peer==user)Accept_Click(this,new RoutedEventArgs());},incoming);
            open.MinWidth=84;open.Margin=new Thickness(0);open.VerticalAlignment=VerticalAlignment.Center;

            var (chipText,chipFg,chipBg)=r.accepted?("Accepted","#4ADE80","#12301F"):incoming?("Incoming","#FFD500","#24210E"):("Invite sent","#B7BAC4","#272A33");
            var chip=new Border{CornerRadius=new CornerRadius(8),Padding=new Thickness(8,3,8,3),Background=Ink(chipBg),VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,12,0),Child=new TextBlock{Text=chipText,FontSize=11,FontWeight=FontWeights.SemiBold,Foreground=Ink(chipFg)}};

            var right=new StackPanel{Orientation=Orientation.Horizontal};
            right.Children.Add(chip);right.Children.Add(open);
            DockPanel.SetDock(right,Dock.Right);row.Children.Add(right);

            var avatar=new Border{Width=44,Height=44,CornerRadius=new CornerRadius(22),Background=(Brush)FindResource("AvatarBrush"),Margin=new Thickness(0,0,14,0),Child=MakeGlyph("\uE77B",18,Ink("#FFD500"))};
            DockPanel.SetDock(avatar,Dock.Left);row.Children.Add(avatar);

            var info=new StackPanel{VerticalAlignment=VerticalAlignment.Center};
            info.Children.Add(new TextBlock{Text=r.name,FontSize=15,FontWeight=FontWeights.SemiBold,Foreground=Brushes.White,TextTrimming=TextTrimming.CharacterEllipsis});
            info.Children.Add(new TextBlock{Text=r.accepted?"Direct conversation":incoming?"Wants to chat with you":"Waiting for them to accept",Foreground=Ink("#9A9EAB"),FontSize=12,Margin=new Thickness(0,2,0,0)});
            row.Children.Add(info);

            card.Child=row;
            HomeRows.Children.Add(card);
        }
    }
}
