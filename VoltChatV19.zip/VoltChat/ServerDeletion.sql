-- V16: apply after PrivateSpaces.sql and ServerChannels.sql.
-- Existing foreign keys cascade removal of server messages, memberships and channels.
begin;
alter table public.volt_spaces enable row level security;
revoke delete on public.volt_spaces from anon;
grant delete on public.volt_spaces to authenticated;
drop policy if exists sp_delete_owner on public.volt_spaces;
create policy sp_delete_owner on public.volt_spaces for delete to authenticated using (owner = (select auth.uid()));
-- Also restrict any other permissive DELETE policy for authenticated users.
drop policy if exists sp_delete_owner_guard on public.volt_spaces;
create policy sp_delete_owner_guard on public.volt_spaces as restrictive for delete to authenticated using (owner = (select auth.uid()));
commit;
