using System;
using System.IO;
using System.Windows;
namespace VoltChat;
public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        DispatcherUnhandledException += (_, args) =>
        {
            var log = Path.Combine(Path.GetTempPath(), "VoltChat-startup.log");
            try { File.WriteAllText(log, args.Exception.ToString()); } catch { }
            MessageBox.Show(args.Exception.Message + "\n\nDiagnostic log: " + log, "Volt Chat error", MessageBoxButton.OK, MessageBoxImage.Error);
            args.Handled = true;
            Shutdown(1);
        };
        // Every window (settings, dialogs, servers) gets the dark title bar once it is created.
        EventManager.RegisterClassHandler(typeof(Window), FrameworkElement.LoadedEvent, new RoutedEventHandler((s, _) => { if (s is Window w) WinChrome.Apply(w, w is MainWindow); }));
        base.OnStartup(e);
    }
}
